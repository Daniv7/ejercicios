
<?php

// Variables

$alumnos = "Alumnos por favor sentarse en el pupitre y guardar silencio.";
$profesores = "Si, ya vamos Prof. Peter";

echo "$alumnos" . "$profesores";

?>









